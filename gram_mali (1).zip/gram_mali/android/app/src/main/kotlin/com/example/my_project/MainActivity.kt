package com.mycompany.gramali

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
